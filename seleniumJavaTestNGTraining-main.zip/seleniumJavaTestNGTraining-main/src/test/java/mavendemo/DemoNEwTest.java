package mavendemo;

public class DemoNEwTest extends BaseTest {
	
	

}
